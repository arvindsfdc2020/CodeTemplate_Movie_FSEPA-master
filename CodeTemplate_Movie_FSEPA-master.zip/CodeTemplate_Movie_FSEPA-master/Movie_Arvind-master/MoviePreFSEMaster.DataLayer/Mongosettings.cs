﻿namespace MoviePreFSEmaster.DataLayer
{
    public class Mongosettings
    {
        public string Connection { get; set; }
        public string DatabaseName { get; set; }
    }
}